import React, {useState} from 'react'
import { Link } from 'react-router-dom';
import { Form, Button, Card } from "react-bootstrap"
import './Login.css'
function Login() {
    const [user, setUser] = useState({
        name: "", 
        password: ""
    });

    const checkUser = (e) => {
       
        e.preventDefault();
        const name = e.target.name;
        const value = e.target.value;
        console.log(name, value);
        setUser({...user,
            [name]:value
        });
        
    }
    return (
        <>
        <Card id='card'>
            <Card.Body>
                <h2 className="text-center mb-4" id='text'>Log In</h2>
                <Form>
                    <Form.Group id="email" value='email'>
                    <Form.Label id='text'>Email</Form.Label>
                    <Form.Control type="email" required 
                        value={user.name}
                        onChange={checkUser}
                    />
                    </Form.Group>
                    <Form.Group id="password" defaultValue='password'>
                    <Form.Label id='text'>Password</Form.Label>
                    <Form.Control type="password" required 
                        value={user.password}
                        onChange={checkUser}
                    />
                    </Form.Group>
                    <Button className="w-100 mt-2" type="submit"  id='btn-sub'>
                        Log In
                    </Button>
                </Form>
            {/* <div className="w-100 text-center mt-3">
                <Link to="/forgot-password">Forgot Password?</Link>
            </div> */}
            </Card.Body>
        </Card>
        <div className="w-100 text-center mt-2">
            Need an account? <Link to="/signup" id='link'>Sign Up</Link>
        </div>
        </>

    )
}

export default Login;
