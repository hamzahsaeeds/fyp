import React from 'react'
// import Banner from './Banner'
// import WorkHistoryIcon from '@mui/icons-material/WorkHistory';
function Home() {
  return (
    <div className='home'
      style={{ background: "linear-gradient(#e66465, #9198e5)" }}>
      {/* <Banner/> */}
      <div className="home_content">
        {/* <WorkHistoryIcon/> */}
      </div>
    </div>
  )
}

export default Home;