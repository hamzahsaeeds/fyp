import React, {useState} from 'react'
import { Form, Button, Card } from "react-bootstrap"
import { Link } from 'react-router-dom'
function Signup() {
     const [newUser, setNewUser] = useState({
          userName: "", 
          userEmail: "", 
          userPassword: "", 
          confirmPassword: ""
     }); 

     const handleInputs = (e) => {
          // console.log(e.name);
          const name = e.target.name;
          const value = e.target.value;
          console.log(name, value);

          setNewUser({...newUser,
               [e.target.name]:e.target.value
          });
     }

     const postData = async(e) => {
          e.preventDefault();
          // destructure
          const {userName, userEmail, userPassword, confirmPassword} = newUser;
          const response = await fetch('/register', {
               method: 'POST',
               headers: {
                    "Content-Type": "application/json"
               },
               body: JSON.stringify({
                    userName, userEmail, userPassword, confirmPassword
               })
          });
          const data = await response.json();
          if(data.status === 422 || !data) {
               window.alert("Error while fetching!");
          } else {
               window.alert("Fetching Successful!")
          }
     }

     return (

          <>
          <Card id='card'>
               <Card.Body>
               <h2 className="text-center mb-4" id='text'>Sign Up</h2>
               <Form method='POST'>
                    <Form.Group id="fullName" name='name'>
                    <Form.Label id='text'>User Name</Form.Label>
                    <Form.Control type="text" required 
                         value={newUser.userName}
                         onChange={handleInputs}
                    />
                    </Form.Group>

                    <Form.Group id="email" name='email'>
                    <Form.Label id='text'>Email</Form.Label>
                    <Form.Control type="email" required 
                         value={newUser.userEmail}
                         onChange={handleInputs}
                    />
                    </Form.Group>
                    
                    <Form.Group id="password" name='password'>
                    <Form.Label id='text'>Password</Form.Label>
                    <Form.Control type="password" required 
                         value={newUser.userPassword}
                         onChange={handleInputs}
                    />
                    </Form.Group>
                    
                    <Form.Group id="password-confirm" name='confirmPassword'>
                    <Form.Label id='text'>Password Confirmation</Form.Label>
                    <Form.Control type="password" required 
                         value={newUser.confirmPassword}
                         onChange={handleInputs}
                    />
                    </Form.Group>
                    
                    <Button className="w-100 mt-3" type="submit"  id='btn-sub' onClick={postData}>
                         
                         Sign Up
                    </Button>
               </Form>
               </Card.Body>
          </Card>
          <div className="w-100 text-center mt-2" >
               Already have an account? <Link to="/login" id='link'>Log In</Link>
          </div>
          </>
     )
    
}

export default Signup;
