import React from 'react'
import './Banner.css'
function Banner() {
  return (
    <header className='banner'
        style={{
            backgroundSize: "cover",
            backgroundImage: 'url("./banner.jpg")',
            backgroundPosition: "center center",
        }}
    >
        {/* <img src="./banner.jpg" alt="" /> */}
        <div className='banner_content'>
            {/* title */}
            <h1>Hire the best</h1> 
            <h1>freelancers for any job!</h1>
        </div>
    </header>
  )
}

export default Banner;