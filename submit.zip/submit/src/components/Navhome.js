import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "react-bootstrap";
// import Home from './Home';

import { Navbar, Nav, Container } from 'react-bootstrap';
import './Navhome.css'  
function Navhome() {
  return (
    <>
      <Navbar bg="background">
        <Container>
        <Navbar.Brand href="#home" className='d-flex'>
          <img
            alt=""
            src="./delance-logo.png"
            width="35"
            height="35"
            className="d-inline-block align-top"
          />{' '}
          <p id='p-logo'>Delance</p>
        </Navbar.Brand>
        <Nav>
            <Nav.Link >
              <Link to="/job-posting" className='text-decoration-none'> 
                <p id='p-tag'>Post a Job </p>
              </Link>
            </Nav.Link>
            <Nav.Link> 
              <Link to="/Login" className='text-decoration-none'>
                <p id='p-tag'>Login</p>
              </Link>
            </Nav.Link>
            <Nav.Link id='signup_btn'> 
              <Link to="/signup" className='text-decoration-none'> 
                <Button type="button"  id='btn'>
                  Signup
                </Button>
              </Link>
            </Nav.Link>
          </Nav> 
        </Container>
          
      </Navbar>
    </>
  )
}

export default Navhome;


