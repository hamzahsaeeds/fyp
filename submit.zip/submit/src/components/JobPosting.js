import React, {useState} from 'react'
import { Form, Button, Card } from "react-bootstrap"
import "./Login.css"
function JobPosting() {

    const [job, setJob] = useState({
        jobTitle: "",
        jobDescription: "",
        budget: "",
        time: "",
        hourlyRate: "",
    })

    const postNewJob = (e) => {
        console.log(e.target.name, e.target.value);
        setJob({...job,
            [e.target.name]:e.target.value
        });
    }

  return (
    <>
        <Card id='card'>
            <Card.Body>
            <h2 className="text-center mb-4" id='text'>Post a Job</h2>
            <Form>
                <Form.Group id="jobTitle">
                <Form.Label id='text'>Job Title</Form.Label>
                <Form.Control type="text" required 
                        value={job.jobTitle}
                        onChange={postNewJob}
                />
                </Form.Group>

                <Form.Group id="description">
                <Form.Label id='text'>Job Description</Form.Label>
                <Form.Control type="text" required
                        value={job.jobDescription}
                        onChange={postNewJob}
                />
                
                </Form.Group>
                
                <Form.Group id="budget">
                <Form.Label id='text'>Budget</Form.Label>
                <Form.Control type="number" required 
                        value={job.budget}
                        onChange={postNewJob}
                        placeholder='$'
                />
                </Form.Group>
                
                <Form.Group id="time">
                <Form.Label id='text'>Time</Form.Label>
                <Form.Control type="number" required 
                        value={job.time}
                        onChange={postNewJob}
                        placeholder='days'
                />
                </Form.Group>

                {/* <Form.Group id="hourlyRate">
                <Form.Label id='card'>Hourly rate</Form.Label>
                <Form.Control type="number" required 
                        value={job.hourlyRate}
                        onChange={postNewJob}
                />
                </Form.Group> */}
                
                <Button className="w-100 mt-3" type="submit"  id='btn-sub'>
                    Post Job
                </Button>
            </Form>
            </Card.Body>
        </Card>
        </>
  )
}

export default JobPosting;