import React from "react"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Login from "./components/Login"
import Signup from "./components/Signup"
import JobPosting from "./components/JobPosting"
import Navhome from "./components/Navhome"
import Home from "./components/Home"
import {Container} from "react-bootstrap"

function App() {
  return (
    <Router>
      <Navhome/>
      <Container
        className="d-flex align-items-center justify-content-center"
        style={{ minHeight: "100vh", maxWidth:"220vh",
          background: "linear-gradient(#FCFFE7, #b7b0a3)"
        }}
      > 
      <div  className="w-100" style={{ maxWidth: "400px" }}>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path="/signup" element={<Signup/>} />
          <Route path="/login" element={<Login />} />
          <Route path="/job-posting" element={<JobPosting />}/>
        </Routes>
      </div>
      </Container>
    </Router>
  )
}

export default App;
