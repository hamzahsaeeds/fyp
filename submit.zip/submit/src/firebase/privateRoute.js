import React, {useContext} from "react";
import {Route, Navigate} from 'react-router-dom';
import { AuthContext } from "./Auth";

const privateRoute = ({component: RounteComponent, ...rest}) => {
    const {currentUser} = useContext(AuthContext);
    return(
        <Route
            {...rest}
            render={routerProps => {
                !!currentUser ? (
                    <RounteComponent {...routerProps}/>
                ) : (
                    <Navigate to={'/login'}/>
                )
            }

            }
        />
    );
}