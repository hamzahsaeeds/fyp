const { response } = require('express');
const express = require('express');
const Signup = require('../models/Signup');
const router = express.Router();
const path = "http://localhost:3000/register";


// GET api
router.get('/', (req, res)=> {
    Signup.find((err, doc)=> {
        if(!err) {
            res.send(doc);
        } else {
            console.log(err);
        }
    });
})

// POST api
router.post('/register', async(req, res)=> {
    let emp = Signup({
        userName: req.body.userName,
        email: req.body.email,
        password: req.body.password
    })

    emp.save((err, doc)=>{
        if(!err) {
            res.send(doc)
        } else {
            console.log(err)
        }
    })
})


module.exports = router;