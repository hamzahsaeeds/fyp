const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/Signup', (err) => {
    if(!err) {
        console.log("connection established successfully!")
    } else {
        console.log(err);
    }
});

module.exports = mongoose;