const mongoose = require('mongoose');

const Signup = mongoose.model('Signup', {
    userName: {
        type:String,
        require
    },      
    email: {
        type:String,
        require
    },
    password: {
        type:String,
        require
    },
    confirmPassword: {
        type:String,
        require
    }
})

module.exports = Signup