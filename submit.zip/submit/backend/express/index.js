const express = require('express');
const mongoose = require('./db');
const bodyParser = require('body-parser');
const cors = require('cors');
const routes = require('./Routes/routes')
const app = express()

const PORT = 3000

app.use(bodyParser.json());
app.use(cors({origin:"http://localhost/3001"}));
app.use('/register', routes);


app.listen(3000, ()=> console.log(`server listening on port ${PORT}`));